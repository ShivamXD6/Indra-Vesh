#!/system/bin/sh
rm -rf /data/adb/modules/magic-kit
rm -rf "/data/MAGICKIT"