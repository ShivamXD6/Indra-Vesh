#!/system/bin/sh
rm -rf /data/adb/modules/indra-vesh
rm -rf "/sdcard/#INDRA"
rm -rf "/data/INDRA"