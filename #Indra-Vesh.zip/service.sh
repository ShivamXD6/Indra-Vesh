#!/system/bin/sh
if [ ! -d "/data/media/0/#INDRA/Logs" ]; then
mkdir -p "/sdcard/#INDRA/Logs"
fi

touch /data/media/0/#INDRA/Logs/reboot.log
INDLOG="/data/media/0/#INDRA/Logs/reboot.log"
exec 2>>"$INDLOG" 

# Defines
DB=/data/INDRA
SRT=$DB/BLScripts
CONF=$DB/Configs
BLC=$CONF/blc.txt
CFGC=$CONF/cfgc.txt
MODPATH="${0%/*}"

# Read Files (Without Space)
READ() {
  value=$(sed -e '/^[[:blank:]]*#/d;s/[\t\n\r ]//g;/^$/d' "$2" | grep -m 1 "^$1=" | cut -d'=' -f 2)
  echo "$value"
  return $?
}

# Read Files (With Space)
READS() {
  value=$(grep -m 1 "^$1=" "$2" | sed 's/^.*=//')
  echo "${value//[[:space:]]/ }"
}

# Indra's Reboot Logs
echo "##### INDRA - Reboot Logs - [$(date)] #####" >> "$INDLOG"
ind () {
    if [ "$1" = "Exclude" ]; then
      exec 2>/dev/null;
    else
      echo "" >> "$INDLOG"
      echo "$1 - [$(date)]" >> "$INDLOG"
      exec 2>>"$INDLOG" 
    fi
}

# Write
write() {
  if [[ ! -f "$1" ]]; then
    ind "- $1 doesn't exist, skipping..."
    return 1
	fi
  local curval=$(cat "$1" 2> /dev/null)
  if [[ "$curval" == "$2" ]]; then
    ind "- $1 is already set to $2, skipping..."
	return 1
  fi
  chmod +w "$1" 2> /dev/null
   if ! echo "$2" > "$1" 2> /dev/null
   then
     ind "× Failed: $1 -> $2"
	 return 0
   fi
  ind "- $1 $curval -> $2"
}

# Execute Scripts
EXSC() {
    local script="$1"
    local comment="$2"
    chmod +x "$script"
    ind "# $comment"
    . "$script"
}

# Start Executing Indra's Scripts 
cnt=1
for file in "$SRT"/*.sh; do
    if [ -f "$file" ]; then
    filename=$(basename "$file")
    name=$(READS "BLN$cnt" $BLC)
    status=$(READ "BLS$cnt" $BLC)
    EXSC "$file" "Turning $status $name"
    cnt=$((cnt + 1))
    fi
done

# Auto Security Patch Level
YEAR=$(date +%Y)
MONTH=$(date +%m)
MONTH=$((10#$MONTH))
NEXT_MONTH=$((MONTH))
if [ $NEXT_MONTH -gt 12 ]; then
    NEXT_MONTH=1
    YEAR=$((YEAR + 1))
fi
MONTH=$(printf "%02d" $NEXT_MONTH)
YEAR=$(printf "%04d" $YEAR)

# Latest Security Patch
SP="${YEAR}-${MONTH}-05"
ind "# Updating Security Patch Level to $SP"

# Updates Security Patch
sed -i "/ro.build.version.security_patch/s/.*/ro.build.version.security_patch=$SP/" "$MODPATH/system.prop"
sed -i "/ro.vendor.build.security_patch/s/.*/ro.vendor.build.security_patch=$SP/" "$MODPATH/system.prop"
sed -i "/ro.build.version.real_security_patch/s/.*/ro.build.version.real_security_patch=$SP/" "$MODPATH/system.prop"

# Ram Management Tweaks
ind "# Applying Ram Management Tweaks"
write "/sys/module/lowmemorykiller/parameters/enable_adaptive_lmk" "0"
write "/sys/module/lowmemorykiller/parameters/vmpressure_file_min" "33280"
write "/sys/module/lowmemorykiller/parameters/minfree" "2048,4096,8192,16384,24576,32768"

if [ "$(READ "BTLOOP" "$CFGC")" = "Enabled" ]; then
# Check for Bootloop (Disable Indravesh Too if Bootloop Occurs)
# Credit - HuskyDG
ind "# Checking for Bootloop caused by any Module"
disable_modules(){
   ind " - Bootloop Detected, Disabling Modules"
   list="$(find /data/adb/modules/* -prune -type d)"
   modcount
   for module in $list
   do
      touch $module/disable
     modcount = ((modcount + 1))
   done
   ind " - Disabled $modcount modules Including Myself :)"
   rm -rf /cache/.system_booting /data/unencrypted/.system_booting /metadata/.system_booting /persist/.system_booting /mnt/vendor/persist/.system_booting
   ind " - Rebooting Now"
   reboot
   exit
}

# Gather Process IDs & Disable Modules if zygote not started or PID didn't match
sleep 15
ZYGOTE_PID1=$(getprop init.svc_debug_pid.zygote)
sleep 15
ZYGOTE_PID2=$(getprop init.svc_debug_pid.zygote)
sleep 15
ZYGOTE_PID3=$(getprop init.svc_debug_pid.zygote)
if [ -z "$ZYGOTE_PID1" ]
then
   ind " - Zygote didn't start? Disabling Modules"
   disable_modules
fi
if [ "$ZYGOTE_PID1" != "$ZYGOTE_PID2" -o "$ZYGOTE_PID2" != "$ZYGOTE_PID3" ]
then
   ind " - PID mismatch, checking again $ZYGOTE_PID1 ≠ $ZYGOTE_PID2 ≠ $ZYGOTE_PID3"   
   sleep 10
   ZYGOTE_PID4=$(getprop init.svc_debug_pid.zygote)
   if [ "$ZYGOTE_PID3" != "$ZYGOTE_PID4" ]
   then
      ind " - Still Process ID not matched $ZYGOTE_PID3 ≠ $ZYGOTE_PID4..."
      disable_modules
   fi
fi
fi
# After Boot Complete 
{
 until [[ -e "/sdcard/" ]]; do
        sleep 1
    done

ind "# Mobile Turned on, Applying Remaining Changes"
if [ "$(READ "CSST" "$CFGC")" = "Enabled" ]; then
CS="$(READ "CSDI" "$CFGC")"
mkdir -p "$DB/Custom"
# Copy Custom Scripts to Database Dir
for script in "$CS"/*.sh; do
    if [ -f "$script" ]; then
        filename=$(basename "$script")
        cp "$script" "$DB/Custom/$filename"
    fi
done

# Start Executing Custom Scripts
for file in "$DB/Custom"/*.sh; do
    if [ -f "$file" ]; then
    filename=$(basename "$file")
   EXSC "$file" "Successfully Executed your Custom $filename Script"
    fi
done
rm -rf "$DB/Custom"
fi

# Indra's Menu Logs
touch /sdcard/#INDRA/Logs/menu.log
INDMLOG="/sdcard/#INDRA/Logs/menu.log"
echo "##### INDRA - Menu Logs - [$(date)] #####" > "$INDMLOG"
echo "" >> "$INDMLOG"
echo "# Write 'su -c indra' in Termux to access menu" >> "$INDMLOG"
if [ "$(READ "LOGS" "$CFGC")" = "Disabled" ]; then
rm -rf /sdcard/#INDRA/Logs/*
fi
}&
